

const wrapper=document.querySelector('.wrapper');
const menu=document.querySelector('.burger');
const canvas=document.querySelector('.canvas');
const close=document.querySelector('.close');
const blur=document.querySelector('.blur');

menu.addEventListener('click',function(){
    canvas.style.width='50%';
    blur.style.filter='blur(5px)';
})
close.addEventListener('click',function(){
    canvas.style.width='0px';
    blur.style.filter='none';
})

setTimeout(function(){
   
    document.querySelector('.load').style.display='none';
    

},1000)

setInterval(function(){
    
    var a = wrapper.getBoundingClientRect().left;

        if(a == 200){
            
            wrapper.style.transform=`translateX(${-430}px)`;    
        }
        
        if(a == -230){
            
            wrapper.style.transform=`translateX(${-830}px)`;    
        }
        if(a == -630){
            
            wrapper.style.transform=`translateX(${0}px)`;    
        }
        
        
   
    

    
},5000)
window.addEventListener('scroll',show);
function show(){
    console.log("hi");

var item=document.querySelectorAll('.motion');
for(var i=0;i<item.length;i++){
    var window_height=window.innerHeight;
    var el_top=item[i].getBoundingClientRect().top;
    var el_height=500;
    if(el_top < window_height){
        item[i].classList.add('moveup');
        console.log("in")
    }
    else{
        item[i].classList.remove('moveup');
        console.log('out');
    }

}
}